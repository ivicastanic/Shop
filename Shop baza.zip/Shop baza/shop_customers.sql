-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: shop
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) CHARACTER SET sjis NOT NULL,
  `surname` varchar(45) CHARACTER SET sjis NOT NULL,
  `birthday` date NOT NULL,
  `id_address` int NOT NULL,
  `mobile` varchar(45) CHARACTER SET sjis NOT NULL,
  `email` varchar(45) CHARACTER SET sjis NOT NULL,
  `points` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_address_idx` (`id_address`),
  CONSTRAINT `fk_address` FOREIGN KEY (`id_address`) REFERENCES `address` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (1,'Ivona','Stanic','2003-01-24',1,'065324772','ivona@gmail.com',7),(3,'Dejla','Saric','1997-07-08',11,'065234876','dejla@gmail.com',0),(4,'Kenan','Bukva','1990-07-25',12,'061348523','kenan@gmail.com',21),(5,'Eldar','Pedisa','2001-03-31',14,'062245331','eldar@gmail.com',46),(6,'Anja','Tesanovic','2002-07-17',15,'062456321','anja@gmail.com',0),(7,'Ensan','Klepo','1988-03-18',16,'064532776','ensan@gmail.com',39),(8,'Rehima','Granulo','2000-06-29',17,'061445665','rahima@gmail.com',4),(9,'Alden','Efendic','2001-08-30',18,'062245667','alden@gmail.com',0),(10,'Meris','Bucan','2000-06-29',24,'062776543','meris@gmail.com',8),(11,'Nermin','Music','1998-07-08',25,'063256342','nermin@gmail.com',16);
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-07-17 14:12:24
